import { useMemo } from "react";
import * as THREE from "three";
import { useNASAData } from "@/lib/stores/useNASAData";

export default function NASADataOverlay() {
  const { soilMoisture, showDataOverlay } = useNASAData();

  // Create moisture visualization grid
  const moistureGrid = useMemo(() => {
    if (!showDataOverlay) return null;

    const gridSize = 25;
    const positions: [number, number, number][] = [];
    const colors: string[] = [];

    for (let i = 0; i < 5; i++) {
      for (let j = 0; j < 5; j++) {
        positions.push([i * 4 - 8, 0.05, j * 4 - 8]);
        // Get moisture value for this grid cell
        const moisture = soilMoisture[i * 5 + j] || 0.5;
        // Color from brown (dry) to blue (wet)
        const color = new THREE.Color().lerpColors(
          new THREE.Color("#8B4513"),
          new THREE.Color("#4169E1"),
          moisture
        );
        colors.push(`#${color.getHexString()}`);
      }
    }

    return { positions, colors };
  }, [soilMoisture, showDataOverlay]);

  if (!showDataOverlay || !moistureGrid) return null;

  return (
    <group>
      {moistureGrid.positions.map((pos, idx) => (
        <mesh
          key={`moisture-${idx}`}
          position={pos}
          rotation={[-Math.PI / 2, 0, 0]}
        >
          <planeGeometry args={[3.5, 3.5]} />
          <meshBasicMaterial
            color={moistureGrid.colors[idx]}
            transparent
            opacity={0.6}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}
