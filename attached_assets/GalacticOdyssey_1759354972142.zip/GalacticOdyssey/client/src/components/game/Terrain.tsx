import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { useMemo } from "react";

export default function Terrain() {
  // Load grass texture
  const grassTexture = useTexture("/textures/grass.png");
  
  // Configure texture
  useMemo(() => {
    grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
    grassTexture.repeat.set(20, 20);
  }, [grassTexture]);

  return (
    <group>
      {/* Main ground plane */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial
          map={grassTexture}
          color="#5a8f4a"
        />
      </mesh>

      {/* Farm field grids */}
      {Array.from({ length: 5 }).map((_, i) =>
        Array.from({ length: 5 }).map((_, j) => (
          <mesh
            key={`field-${i}-${j}`}
            position={[i * 4 - 8, 0.01, j * 4 - 8]}
            rotation={[-Math.PI / 2, 0, 0]}
            receiveShadow
          >
            <planeGeometry args={[3.5, 3.5]} />
            <meshStandardMaterial
              color="#8B4513"
              roughness={0.9}
            />
          </mesh>
        ))
      )}

      {/* Farm boundaries - simple fence-like markers */}
      {[-12, 12].map((x, idx) => (
        <mesh
          key={`fence-x-${idx}`}
          position={[x, 0.5, 0]}
          castShadow
        >
          <boxGeometry args={[0.3, 1, 30]} />
          <meshStandardMaterial color="#654321" />
        </mesh>
      ))}
      {[-12, 12].map((z, idx) => (
        <mesh
          key={`fence-z-${idx}`}
          position={[0, 0.5, z]}
          castShadow
        >
          <boxGeometry args={[30, 1, 0.3]} />
          <meshStandardMaterial color="#654321" />
        </mesh>
      ))}
    </group>
  );
}
