import { useMemo } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useRef } from "react";

interface Animal {
  id: string;
  position: [number, number, number];
  type: "cow" | "chicken" | "sheep";
  color: string;
}

export default function Livestock() {
  // Pre-calculate animal positions (not in render)
  const animals = useMemo<Animal[]>(() => [
    { id: "cow-1", position: [15, 0, -6], type: "cow", color: "#8B4513" },
    { id: "cow-2", position: [17, 0, -8], type: "cow", color: "#A0522D" },
    { id: "chicken-1", position: [14, 0, -4], type: "chicken", color: "#FFFFFF" },
    { id: "chicken-2", position: [16, 0, -3], type: "chicken", color: "#F5DEB3" },
    { id: "chicken-3", position: [15, 0, -5], type: "chicken", color: "#FFE4B5" },
    { id: "sheep-1", position: [18, 0, -5], type: "sheep", color: "#F0F0F0" },
    { id: "sheep-2", position: [19, 0, -7], type: "sheep", color: "#E8E8E8" },
  ], []);

  return (
    <group>
      {/* Livestock pen fence */}
      <group position={[16.5, 0, -5.5]}>
        {/* Fence posts */}
        {[-4, 4].map((x, idx) => (
          <mesh key={`fence-x-${idx}`} position={[x, 0.75, 0]} castShadow>
            <boxGeometry args={[0.3, 1.5, 8]} />
            <meshStandardMaterial color="#654321" />
          </mesh>
        ))}
        {[-4, 4].map((z, idx) => (
          <mesh key={`fence-z-${idx}`} position={[0, 0.75, z]} castShadow>
            <boxGeometry args={[8, 1.5, 0.3]} />
            <meshStandardMaterial color="#654321" />
          </mesh>
        ))}

        {/* Ground in pen */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]} receiveShadow>
          <planeGeometry args={[8, 8]} />
          <meshStandardMaterial color="#D2B48C" roughness={0.9} />
        </mesh>
      </group>

      {/* Animals */}
      {animals.map((animal) => (
        <AnimalMesh key={animal.id} {...animal} />
      ))}

      {/* Water trough */}
      <mesh position={[14, 0.3, -9]} castShadow>
        <boxGeometry args={[2, 0.5, 0.8]} />
        <meshStandardMaterial color="#1E90FF" />
      </mesh>

      {/* Feed trough */}
      <mesh position={[19, 0.3, -2]} castShadow>
        <boxGeometry args={[2, 0.5, 0.8]} />
        <meshStandardMaterial color="#D2691E" />
      </mesh>
    </group>
  );
}

function AnimalMesh({ position, type, color }: Animal) {
  const meshRef = useRef<THREE.Group>(null);

  // Gentle idle animation
  useFrame((state) => {
    if (meshRef.current) {
      // Subtle bobbing motion
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.05;
      
      // Occasional head turn
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5 + position[2]) * 0.3;
    }
  });

  // Animal size based on type
  const size = type === "cow" ? 1.2 : type === "sheep" ? 0.9 : 0.6;

  return (
    <group ref={meshRef} position={position}>
      {/* Body */}
      <mesh position={[0, size * 0.4, 0]} castShadow>
        <boxGeometry args={[size * 0.8, size * 0.6, size * 1.2]} />
        <meshStandardMaterial color={color} />
      </mesh>

      {/* Head */}
      <mesh position={[0, size * 0.5, size * 0.7]} castShadow>
        <boxGeometry args={[size * 0.5, size * 0.5, size * 0.6]} />
        <meshStandardMaterial color={color} />
      </mesh>

      {/* Legs */}
      {[
        [-size * 0.3, 0, -size * 0.3],
        [size * 0.3, 0, -size * 0.3],
        [-size * 0.3, 0, size * 0.3],
        [size * 0.3, 0, size * 0.3],
      ].map((pos, idx) => (
        <mesh key={idx} position={pos as [number, number, number]} castShadow>
          <boxGeometry args={[size * 0.15, size * 0.5, size * 0.15]} />
          <meshStandardMaterial color={color} />
        </mesh>
      ))}
    </group>
  );
}
