import { useRef, useMemo } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { CropType } from "@/lib/stores/useFarm";

interface CropProps {
  id: string;
  position: [number, number, number];
  type: CropType;
  growth: number; // 0-1
  health: number; // 0-1
}

export default function Crop({ id, position, type, growth, health }: CropProps) {
  const meshRef = useRef<THREE.Mesh>(null);

  // Crop type to color mapping
  const cropColors: Record<CropType, string> = {
    wheat: "#F4A460",    // Sandy brown
    corn: "#FFD700",     // Gold
    soybean: "#90EE90",  // Light green
    potato: "#D2691E",   // Chocolate
  };

  // Calculate crop appearance based on growth and health
  const { scale, color } = useMemo(() => {
    const baseScale = 0.5 + growth * 1.5;
    const cropColor = cropColors[type] || "#32CD32";
    
    // Mix crop-specific color with health indicator
    const healthyColor = new THREE.Color(cropColor);
    const unhealthyColor = new THREE.Color("#8B4513"); // Brown
    const healthColor = new THREE.Color().lerpColors(
      unhealthyColor,
      healthyColor,
      health
    );
    return { scale: baseScale, color: healthColor };
  }, [growth, health, type]);

  // Gentle sway animation
  useFrame((state) => {
    if (meshRef.current && growth > 0.3) {
      meshRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.05;
    }
  });

  return (
    <group position={position}>
      {/* Crop stem/plant */}
      <mesh ref={meshRef} position={[0, scale * 0.5, 0]} castShadow>
        <boxGeometry args={[0.2, scale, 0.2]} />
        <meshStandardMaterial color={color} />
      </mesh>

      {/* Crop leaves/foliage if grown enough */}
      {growth > 0.5 && (
        <>
          <mesh position={[0.3, scale * 0.7, 0]} castShadow>
            <boxGeometry args={[0.4, 0.1, 0.3]} />
            <meshStandardMaterial color={color} />
          </mesh>
          <mesh position={[-0.3, scale * 0.7, 0]} castShadow>
            <boxGeometry args={[0.4, 0.1, 0.3]} />
            <meshStandardMaterial color={color} />
          </mesh>
          <mesh position={[0, scale * 0.7, 0.3]} castShadow>
            <boxGeometry args={[0.3, 0.1, 0.4]} />
            <meshStandardMaterial color={color} />
          </mesh>
          <mesh position={[0, scale * 0.7, -0.3]} castShadow>
            <boxGeometry args={[0.3, 0.1, 0.4]} />
            <meshStandardMaterial color={color} />
          </mesh>
        </>
      )}

      {/* Harvest indicator when fully grown */}
      {growth >= 0.95 && health > 0.7 && (
        <mesh position={[0, scale + 0.5, 0]}>
          <sphereGeometry args={[0.15, 8, 8]} />
          <meshStandardMaterial
            color="#FFD700"
            emissive="#FFD700"
            emissiveIntensity={0.5}
          />
        </mesh>
      )}
    </group>
  );
}
