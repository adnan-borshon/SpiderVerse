import { useEffect, useRef } from "react";
import { Howl } from "howler";
import { useAudio } from "@/lib/stores/useAudio";
import { useGame } from "@/lib/stores/useGame";

export default function SoundManager() {
  const { phase } = useGame();
  const { isMuted } = useAudio();
  const backgroundMusicRef = useRef<Howl | null>(null);
  const plantSoundRef = useRef<Howl | null>(null);
  const waterSoundRef = useRef<Howl | null>(null);
  const harvestSoundRef = useRef<Howl | null>(null);

  // Initialize sounds
  useEffect(() => {
    // Background music
    backgroundMusicRef.current = new Howl({
      src: ["/sounds/background.mp3"],
      loop: true,
      volume: 0.3,
    });

    // Plant sound (using hit as planting sound)
    plantSoundRef.current = new Howl({
      src: ["/sounds/hit.mp3"],
      volume: 0.4,
    });

    // Water sound (using hit with lower pitch)
    waterSoundRef.current = new Howl({
      src: ["/sounds/hit.mp3"],
      volume: 0.3,
      rate: 0.7,
    });

    // Harvest sound (using success)
    harvestSoundRef.current = new Howl({
      src: ["/sounds/success.mp3"],
      volume: 0.5,
    });

    return () => {
      backgroundMusicRef.current?.unload();
      plantSoundRef.current?.unload();
      waterSoundRef.current?.unload();
      harvestSoundRef.current?.unload();
    };
  }, []);

  // Handle background music
  useEffect(() => {
    if (!backgroundMusicRef.current) return;

    if (phase === "playing" && !isMuted) {
      backgroundMusicRef.current.play();
    } else {
      backgroundMusicRef.current.pause();
    }
  }, [phase, isMuted]);

  // Expose sound playing functions globally
  useEffect(() => {
    (window as any).playPlantSound = () => {
      if (!isMuted && plantSoundRef.current) {
        plantSoundRef.current.play();
      }
    };

    (window as any).playWaterSound = () => {
      if (!isMuted && waterSoundRef.current) {
        waterSoundRef.current.play();
      }
    };

    (window as any).playHarvestSound = () => {
      if (!isMuted && harvestSoundRef.current) {
        harvestSoundRef.current.play();
      }
    };
  }, [isMuted]);

  return null;
}
