import { useRef } from "react";
import { OrbitControls } from "@react-three/drei";
import Terrain from "./Terrain";
import Player from "./Player";
import Crop from "./Crop";
import Livestock from "./Livestock";
import { useFarm } from "@/lib/stores/useFarm";
import NASADataOverlay from "./NASADataOverlay";

export default function Scene() {
  const { crops, fields } = useFarm();

  return (
    <>
      {/* Camera controls */}
      <OrbitControls
        enablePan={false}
        maxPolarAngle={Math.PI / 2.5}
        minDistance={10}
        maxDistance={50}
        target={[0, 0, 0]}
      />

      {/* Terrain */}
      <Terrain />

      {/* Player */}
      <Player />

      {/* Crops */}
      {crops.map((crop) => (
        <Crop
          key={crop.id}
          id={crop.id}
          position={crop.position}
          type={crop.type}
          growth={crop.growth}
          health={crop.health}
        />
      ))}

      {/* Livestock */}
      <Livestock />

      {/* NASA Data Visualization Overlay */}
      <NASADataOverlay />
    </>
  );
}
