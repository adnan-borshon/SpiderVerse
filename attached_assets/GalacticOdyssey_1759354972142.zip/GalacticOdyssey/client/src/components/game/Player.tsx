import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { Controls } from "@/App";
import { useFarm } from "@/lib/stores/useFarm";

export default function Player() {
  const playerRef = useRef<THREE.Group>(null);
  const { playerPosition, setPlayerPosition, selectedAction, performAction } = useFarm();
  const [subscribeKeys, getKeys] = useKeyboardControls<Controls>();

  // Player movement speed
  const speed = 0.15;

  // Handle E key for performing actions
  useEffect(() => {
    const unsubscribe = subscribeKeys(
      (state) => state.interact,
      (pressed) => {
        if (pressed) {
          performAction();
        }
      }
    );
    return unsubscribe;
  }, [subscribeKeys, performAction]);

  useFrame(() => {
    if (!playerRef.current) return;

    const controls = getKeys();
    const moveVector = new THREE.Vector3();

    // Handle movement
    if (controls.forward) moveVector.z -= 1;
    if (controls.backward) moveVector.z += 1;
    if (controls.leftward) moveVector.x -= 1;
    if (controls.rightward) moveVector.x += 1;

    // Normalize and apply speed
    if (moveVector.length() > 0) {
      moveVector.normalize().multiplyScalar(speed);
      const newPos = playerRef.current.position.clone().add(moveVector);

      // Constrain to farm boundaries
      newPos.x = Math.max(-11, Math.min(11, newPos.x));
      newPos.z = Math.max(-11, Math.min(11, newPos.z));

      playerRef.current.position.copy(newPos);
      setPlayerPosition([newPos.x, newPos.y, newPos.z]);

      // Rotate player to face movement direction
      if (moveVector.x !== 0 || moveVector.z !== 0) {
        const angle = Math.atan2(moveVector.x, moveVector.z);
        playerRef.current.rotation.y = angle;
      }
    }
  });

  // Visual indicator for selected action
  const actionColor = {
    plant: "#90EE90",
    water: "#1E90FF",
    fertilize: "#FFD700",
    harvest: "#FF6347",
    none: "#4169E1"
  }[selectedAction];

  return (
    <group ref={playerRef} position={playerPosition}>
      {/* Player body */}
      <mesh position={[0, 0.5, 0]} castShadow>
        <boxGeometry args={[0.8, 1, 0.8]} />
        <meshStandardMaterial color={actionColor} />
      </mesh>

      {/* Player head */}
      <mesh position={[0, 1.3, 0]} castShadow>
        <boxGeometry args={[0.5, 0.5, 0.5]} />
        <meshStandardMaterial color="#FFE4C4" />
      </mesh>

      {/* Action indicator ring */}
      <mesh position={[0, 0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.2, 1.5, 32]} />
        <meshBasicMaterial
          color={actionColor}
          transparent
          opacity={0.3}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}
