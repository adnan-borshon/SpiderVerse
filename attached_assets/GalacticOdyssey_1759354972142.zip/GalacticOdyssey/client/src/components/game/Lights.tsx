import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFarm } from "@/lib/stores/useFarm";

export default function Lights() {
  const sunRef = useRef<THREE.DirectionalLight>(null);
  const { season, timeOfDay } = useFarm();

  // Adjust lighting based on time of day and season
  useFrame(() => {
    if (!sunRef.current) return;

    // Simple day/night cycle
    const dayProgress = timeOfDay / 24; // 0-1
    const sunAngle = dayProgress * Math.PI * 2;
    
    sunRef.current.position.x = Math.cos(sunAngle) * 20;
    sunRef.current.position.y = Math.sin(sunAngle) * 20 + 10;
    
    // Adjust intensity based on time
    const intensity = Math.max(0.3, Math.sin(sunAngle) * 0.8 + 0.4);
    sunRef.current.intensity = intensity;
  });

  return (
    <>
      {/* Ambient light */}
      <ambientLight intensity={0.4} />

      {/* Main directional light (sun) */}
      <directionalLight
        ref={sunRef}
        position={[10, 20, 10]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />

      {/* Hemisphere light for natural outdoor lighting */}
      <hemisphereLight
        color="#87CEEB"
        groundColor="#5a8f4a"
        intensity={0.5}
      />
    </>
  );
}
