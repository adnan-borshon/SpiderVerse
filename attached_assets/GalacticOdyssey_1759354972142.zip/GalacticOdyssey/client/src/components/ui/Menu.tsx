import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { useGame } from "@/lib/stores/useGame";
import { useTutorial } from "@/lib/stores/useTutorial";
import { Sprout } from "lucide-react";

export default function Menu() {
  const { start } = useGame();
  const { setShowTutorial } = useTutorial();

  const handleStart = () => {
    start();
  };

  const handleStartWithTutorial = () => {
    setShowTutorial(true);
    start();
  };

  return (
    <div className="absolute inset-0 bg-gradient-to-b from-sky-400 to-green-400 flex items-center justify-center">
      <Card className="max-w-2xl w-full mx-4 bg-white/95">
        <CardHeader>
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sprout className="w-12 h-12 text-green-600" />
            <CardTitle className="text-4xl font-bold text-center">
              NASA Farm Navigators
            </CardTitle>
          </div>
          <p className="text-center text-gray-600">
            Learn sustainable farming with NASA satellite data
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <h3 className="font-bold mb-2 text-blue-900">About This Game</h3>
            <p className="text-sm text-gray-700">
              Use real NASA Earth observation data to manage your farm! Monitor soil moisture,
              vegetation health, and weather conditions to make informed decisions about planting,
              irrigation, and harvesting. Practice sustainable agriculture while learning how
              satellite data helps farmers worldwide.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-green-50 p-3 rounded border border-green-200">
              <h4 className="font-semibold text-green-900 mb-1">🌱 Plant Crops</h4>
              <p className="text-xs text-gray-600">Choose the right time and location</p>
            </div>
            <div className="bg-blue-50 p-3 rounded border border-blue-200">
              <h4 className="font-semibold text-blue-900 mb-1">💧 Manage Water</h4>
              <p className="text-xs text-gray-600">Use NASA soil moisture data</p>
            </div>
            <div className="bg-yellow-50 p-3 rounded border border-yellow-200">
              <h4 className="font-semibold text-yellow-900 mb-1">🌾 Monitor Growth</h4>
              <p className="text-xs text-gray-600">Track vegetation health indices</p>
            </div>
            <div className="bg-red-50 p-3 rounded border border-red-200">
              <h4 className="font-semibold text-red-900 mb-1">📊 Analyze Data</h4>
              <p className="text-xs text-gray-600">Make data-driven decisions</p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleStartWithTutorial}
              size="lg"
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              Start with Tutorial
            </Button>
            <Button
              onClick={handleStart}
              size="lg"
              variant="outline"
              className="flex-1"
            >
              Start Game
            </Button>
          </div>

          <div className="text-center text-xs text-gray-500">
            NASA Space Apps Challenge 2025
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
