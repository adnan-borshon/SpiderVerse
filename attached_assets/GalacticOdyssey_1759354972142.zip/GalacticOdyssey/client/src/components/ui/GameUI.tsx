import { useState } from "react";
import { Button } from "./button";
import { Card } from "./card";
import ResourceBar from "./ResourceBar";
import DataPanel from "./DataPanel";
import Tutorial from "./Tutorial";
import { useFarm } from "@/lib/stores/useFarm";
import { useGame } from "@/lib/stores/useGame";
import { useAudio } from "@/lib/stores/useAudio";
import { useTutorial } from "@/lib/stores/useTutorial";
import { Volume2, VolumeX, Info, Eye, EyeOff } from "lucide-react";
import { useNASAData } from "@/lib/stores/useNASAData";

export default function GameUI() {
  const { phase, end } = useGame();
  const { isMuted, toggleMute } = useAudio();
  const { showTutorial, setShowTutorial } = useTutorial();
  const { showDataOverlay, toggleDataOverlay } = useNASAData();
  const {
    selectedAction,
    setSelectedAction,
    selectedCropType,
    setSelectedCropType,
    performAction,
    resources,
    score,
    season,
    day,
  } = useFarm();

  const actions = [
    { id: "plant", label: "Plant (1)", color: "bg-green-500" },
    { id: "water", label: "Water (2)", color: "bg-blue-500" },
    { id: "fertilize", label: "Fertilize (3)", color: "bg-yellow-500" },
    { id: "harvest", label: "Harvest (Space)", color: "bg-red-500" },
  ];

  const cropTypes: Array<{ id: import("@/lib/stores/useFarm").CropType; label: string; color: string }> = [
    { id: "wheat", label: "🌾 Wheat", color: "#F4A460" },
    { id: "corn", label: "🌽 Corn", color: "#FFD700" },
    { id: "soybean", label: "🫘 Soybean", color: "#90EE90" },
    { id: "potato", label: "🥔 Potato", color: "#D2691E" },
  ];

  return (
    <>
      {/* Top Bar - Resources and Info */}
      <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start pointer-events-none">
        <div className="pointer-events-auto">
          <ResourceBar />
        </div>

        <Card className="bg-black/80 text-white p-4 pointer-events-auto">
          <div className="text-sm space-y-1">
            <div>Season: {season}</div>
            <div>Day: {day}</div>
            <div className="text-xl font-bold text-yellow-400">Score: {score}</div>
          </div>
        </Card>
      </div>

      {/* Left Side - Data Panel */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
        <div className="pointer-events-auto">
          <DataPanel />
        </div>
      </div>

      {/* Bottom Bar - Actions */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col gap-2 pointer-events-auto items-center">
        {/* Action Buttons */}
        <div className="flex gap-2">
          {actions.map((action) => (
            <Button
              key={action.id}
              onClick={() => setSelectedAction(action.id as any)}
              className={`${action.color} ${
                selectedAction === action.id ? "ring-4 ring-white" : ""
              } text-white font-bold`}
            >
              {action.label}
            </Button>
          ))}
        </div>

        {/* Crop Type Selector */}
        {selectedAction === "plant" && (
          <Card className="bg-black/80 p-2">
            <div className="flex gap-2">
              {cropTypes.map((crop) => (
                <Button
                  key={crop.id}
                  onClick={() => setSelectedCropType(crop.id)}
                  size="sm"
                  variant={selectedCropType === crop.id ? "default" : "outline"}
                  style={{
                    backgroundColor: selectedCropType === crop.id ? crop.color : undefined,
                    borderColor: crop.color,
                  }}
                  className="text-white font-semibold"
                >
                  {crop.label}
                </Button>
              ))}
            </div>
          </Card>
        )}
      </div>

      {/* Right Side Controls */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2 pointer-events-auto">
        <Button
          onClick={toggleMute}
          size="icon"
          variant="secondary"
          className="bg-black/80 text-white hover:bg-black/60"
        >
          {isMuted ? <VolumeX /> : <Volume2 />}
        </Button>

        <Button
          onClick={() => setShowTutorial(true)}
          size="icon"
          variant="secondary"
          className="bg-black/80 text-white hover:bg-black/60"
        >
          <Info />
        </Button>

        <Button
          onClick={toggleDataOverlay}
          size="icon"
          variant="secondary"
          className="bg-black/80 text-white hover:bg-black/60"
        >
          {showDataOverlay ? <EyeOff /> : <Eye />}
        </Button>
      </div>

      {/* Tutorial Overlay */}
      {showTutorial && <Tutorial />}

      {/* Game End Screen */}
      {phase === "ended" && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center pointer-events-auto">
          <Card className="bg-white p-8 max-w-md text-center">
            <h2 className="text-3xl font-bold mb-4">Season Complete!</h2>
            <p className="text-xl mb-2">Final Score: {score}</p>
            <p className="mb-6">
              You've completed a farming season using NASA satellite data!
            </p>
            <Button onClick={() => window.location.reload()} size="lg">
              Play Again
            </Button>
          </Card>
        </div>
      )}

      {/* Controls Help */}
      <div className="absolute bottom-4 left-4 pointer-events-none">
        <Card className="bg-black/80 text-white text-xs p-3">
          <div className="space-y-1">
            <div>WASD/Arrows: Move</div>
            <div>1-3: Select Action</div>
            <div>Space: Harvest</div>
            <div>E: Perform Action</div>
          </div>
        </Card>
      </div>
    </>
  );
}
