import { Card } from "./card";
import { useNASAData } from "@/lib/stores/useNASAData";
import { useFarm } from "@/lib/stores/useFarm";
import { Droplets, Thermometer, Wind, Sun } from "lucide-react";

export default function DataPanel() {
  const { avgSoilMoisture, temperature, precipitation, vegetationIndex } = useNASAData();
  const { season } = useFarm();

  const dataItems = [
    {
      icon: <Droplets className="w-5 h-5" />,
      label: "Soil Moisture",
      value: `${(avgSoilMoisture * 100).toFixed(0)}%`,
      color: "text-blue-600",
      description: "NASA SMAP data",
    },
    {
      icon: <Thermometer className="w-5 h-5" />,
      label: "Temperature",
      value: `${temperature.toFixed(1)}°C`,
      color: "text-red-600",
      description: "Surface temperature",
    },
    {
      icon: <Wind className="w-5 h-5" />,
      label: "Precipitation",
      value: `${precipitation.toFixed(1)}mm`,
      color: "text-cyan-600",
      description: "Daily rainfall",
    },
    {
      icon: <Sun className="w-5 h-5" />,
      label: "Vegetation Index",
      value: vegetationIndex.toFixed(2),
      color: "text-green-600",
      description: "NDVI from MODIS",
    },
  ];

  return (
    <Card className="bg-black/80 text-white p-4 w-64">
      <div className="text-sm font-bold mb-3 text-yellow-400">
        NASA Earth Data - {season}
      </div>
      <div className="space-y-3">
        {dataItems.map((item, idx) => (
          <div key={idx} className="flex items-start gap-3">
            <div className={item.color}>{item.icon}</div>
            <div className="flex-1">
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-gray-300">{item.label}</span>
                <span className="font-bold">{item.value}</span>
              </div>
              <div className="text-xs text-gray-400 mt-0.5">
                {item.description}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-3 border-t border-gray-600 text-xs text-gray-400">
        Data refreshes in real-time to simulate actual farming conditions
      </div>
    </Card>
  );
}
