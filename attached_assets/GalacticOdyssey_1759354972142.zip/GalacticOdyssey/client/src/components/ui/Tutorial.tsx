import { useState } from "react";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { useTutorial } from "@/lib/stores/useTutorial";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

const tutorialSteps = [
  {
    title: "Welcome to NASA Farm Navigators!",
    content: "This game teaches sustainable farming using real NASA satellite data. You'll learn how Earth observation helps farmers make better decisions.",
  },
  {
    title: "NASA Data Sources",
    content: "We use data from NASA's SMAP (Soil Moisture Active Passive) mission, MODIS (vegetation indices), and climate models. This data is updated regularly and used by real farmers worldwide!",
  },
  {
    title: "Movement & Controls",
    content: "Use WASD or Arrow keys to move around your farm. Press E to perform the selected action at your current location.",
  },
  {
    title: "Farming Actions",
    content: "Select actions using number keys (1-4) or click the buttons:\n• Plant (1): Start growing crops\n• Water (2): Irrigate based on soil moisture\n• Fertilize (3): Add nutrients\n• Harvest (Space): Collect mature crops",
  },
  {
    title: "Soil Moisture Data",
    content: "The blue overlay shows soil moisture levels from NASA SMAP. Dark blue = wet soil, brown = dry soil. Water only when needed to conserve resources!",
  },
  {
    title: "Resource Management",
    content: "Monitor your water, fertilizer, and seeds. Use resources wisely based on the satellite data. Sustainable farming means doing more with less!",
  },
  {
    title: "Crop Growth",
    content: "Crops grow based on real conditions: soil moisture, temperature, and nutrients. Healthy crops are green, unhealthy ones turn brown. Harvest when crops show a golden indicator!",
  },
  {
    title: "Seasonal Cycles",
    content: "The game follows realistic seasons. Different seasons have different growing conditions. Pay attention to temperature and precipitation patterns!",
  },
  {
    title: "Scoring System",
    content: "Earn points by:\n• Harvesting healthy crops\n• Efficient resource use\n• Maintaining high crop health\n• Making data-driven decisions",
  },
  {
    title: "Ready to Farm!",
    content: "Remember: Use NASA data to guide your decisions, conserve resources, and farm sustainably. Good luck, Farm Navigator!",
  },
];

export default function Tutorial() {
  const [currentStep, setCurrentStep] = useState(0);
  const { setShowTutorial } = useTutorial();

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowTutorial(false);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const step = tutorialSteps[currentStep];

  return (
    <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-50 pointer-events-auto">
      <Card className="max-w-2xl w-full mx-4 bg-white">
        <CardHeader className="relative">
          <Button
            onClick={() => setShowTutorial(false)}
            size="icon"
            variant="ghost"
            className="absolute right-2 top-2"
          >
            <X />
          </Button>
          <CardTitle className="text-2xl">{step.title}</CardTitle>
          <div className="text-sm text-gray-500">
            Step {currentStep + 1} of {tutorialSteps.length}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="min-h-[150px] whitespace-pre-line">
            {step.content}
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <Button
              onClick={prevStep}
              disabled={currentStep === 0}
              variant="outline"
            >
              <ChevronLeft className="mr-2" />
              Previous
            </Button>

            <div className="flex gap-1">
              {tutorialSteps.map((_, idx) => (
                <div
                  key={idx}
                  className={`w-2 h-2 rounded-full ${
                    idx === currentStep ? "bg-blue-600" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>

            <Button onClick={nextStep} className="bg-blue-600 hover:bg-blue-700">
              {currentStep === tutorialSteps.length - 1 ? "Start Farming!" : "Next"}
              <ChevronRight className="ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
