import { Card } from "./card";
import { useFarm } from "@/lib/stores/useFarm";
import { Droplet, Beaker, Sprout } from "lucide-react";

export default function ResourceBar() {
  const { resources } = useFarm();

  const resourceItems = [
    {
      icon: <Droplet className="w-5 h-5 text-blue-500" />,
      label: "Water",
      current: resources.water,
      max: 100,
      color: "bg-blue-500",
    },
    {
      icon: <Beaker className="w-5 h-5 text-yellow-500" />,
      label: "Fertilizer",
      current: resources.fertilizer,
      max: 100,
      color: "bg-yellow-500",
    },
    {
      icon: <Sprout className="w-5 h-5 text-green-500" />,
      label: "Seeds",
      current: resources.seeds,
      max: 50,
      color: "bg-green-500",
    },
  ];

  return (
    <Card className="bg-black/80 text-white p-4">
      <div className="space-y-3 min-w-[200px]">
        {resourceItems.map((item, idx) => (
          <div key={idx}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                {item.icon}
                <span className="text-sm font-semibold">{item.label}</span>
              </div>
              <span className="text-sm">
                {item.current}/{item.max}
              </span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div
                className={`${item.color} h-2 rounded-full transition-all duration-300`}
                style={{ width: `${(item.current / item.max) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
