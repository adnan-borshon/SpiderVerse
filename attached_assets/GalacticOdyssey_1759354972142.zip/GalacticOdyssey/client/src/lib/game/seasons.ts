/**
 * Season Data
 * 
 * Environmental conditions for each season
 */

export interface SeasonData {
  name: string;
  avgTemperature: number;
  avgPrecipitation: number;
  avgSoilMoisture: number;
  dayLength: number; // hours
}

export const seasons: Record<string, SeasonData> = {
  Spring: {
    name: "Spring",
    avgTemperature: 15,
    avgPrecipitation: 8,
    avgSoilMoisture: 0.6,
    dayLength: 12,
  },
  Summer: {
    name: "Summer",
    avgTemperature: 28,
    avgPrecipitation: 3,
    avgSoilMoisture: 0.4,
    dayLength: 14,
  },
  Fall: {
    name: "Fall",
    avgTemperature: 18,
    avgPrecipitation: 6,
    avgSoilMoisture: 0.5,
    dayLength: 11,
  },
  Winter: {
    name: "Winter",
    avgTemperature: 5,
    avgPrecipitation: 10,
    avgSoilMoisture: 0.7,
    dayLength: 9,
  },
};
