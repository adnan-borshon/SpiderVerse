/**
 * Crop Data
 * 
 * Information about different crop types and their requirements
 */

export interface CropType {
  id: string;
  name: string;
  growthDays: number;
  waterRequirement: number; // 0-1
  fertilizerRequirement: number; // 0-1
  optimalTemp: { min: number; max: number };
  seasonPreference: string[];
}

export const cropTypes: Record<string, CropType> = {
  wheat: {
    id: "wheat",
    name: "Wheat",
    growthDays: 20,
    waterRequirement: 0.5,
    fertilizerRequirement: 0.4,
    optimalTemp: { min: 10, max: 25 },
    seasonPreference: ["Spring", "Fall"],
  },
  corn: {
    id: "corn",
    name: "Corn",
    growthDays: 25,
    waterRequirement: 0.7,
    fertilizerRequirement: 0.6,
    optimalTemp: { min: 15, max: 30 },
    seasonPreference: ["Spring", "Summer"],
  },
  soybean: {
    id: "soybean",
    name: "Soybean",
    growthDays: 22,
    waterRequirement: 0.6,
    fertilizerRequirement: 0.3,
    optimalTemp: { min: 18, max: 28 },
    seasonPreference: ["Spring", "Summer"],
  },
  potato: {
    id: "potato",
    name: "Potato",
    growthDays: 18,
    waterRequirement: 0.6,
    fertilizerRequirement: 0.5,
    optimalTemp: { min: 12, max: 22 },
    seasonPreference: ["Spring", "Fall"],
  },
};
