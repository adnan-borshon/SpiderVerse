import { cropTypes } from "./cropData";
import { useNASAData } from "../stores/useNASAData";

/**
 * Calculate crop growth based on environmental conditions
 * This simulates real farming conditions using NASA data
 */
export function calculateCropGrowth(crop: any, farmState: any): number {
  const cropData = cropTypes[crop.type];
  if (!cropData) return crop.growth;
  
  const nasaData = useNASAData.getState();
  const daysSincePlanted = farmState.day - crop.plantedDay;
  
  // Base growth rate
  let growthRate = 1 / cropData.growthDays;
  
  // Temperature factor
  const temp = nasaData.temperature;
  const tempOptimal = (cropData.optimalTemp.min + cropData.optimalTemp.max) / 2;
  const tempRange = cropData.optimalTemp.max - cropData.optimalTemp.min;
  const tempFactor = Math.max(0, 1 - Math.abs(temp - tempOptimal) / tempRange);
  
  // Water factor (from NASA SMAP data)
  const daysSinceWatered = farmState.day - crop.lastWatered;
  const waterFactor = daysSinceWatered <= 2 ? 1 : Math.max(0.3, 1 - (daysSinceWatered - 2) * 0.1);
  
  // Fertilizer boost
  const daysSinceFertilized = farmState.day - crop.lastFertilized;
  const fertilizerBoost = daysSinceFertilized <= 5 ? 1.2 : 1;
  
  // Season factor
  const seasonBonus = cropData.seasonPreference.includes(farmState.season) ? 1.1 : 0.9;
  
  // Calculate final growth
  const totalGrowth = crop.growth + (growthRate * tempFactor * waterFactor * fertilizerBoost * seasonBonus);
  
  return Math.min(1, totalGrowth);
}
