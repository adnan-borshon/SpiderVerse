import { create } from "zustand";
import { useFarm } from "./useFarm";

interface NASADataState {
  soilMoisture: number[]; // 0-1 for each grid cell
  avgSoilMoisture: number;
  temperature: number;
  precipitation: number;
  vegetationIndex: number;
  showDataOverlay: boolean;
  
  // Actions
  updateData: () => void;
  toggleDataOverlay: () => void;
}

export const useNASAData = create<NASADataState>((set, get) => ({
  soilMoisture: Array(25).fill(0.5),
  avgSoilMoisture: 0.5,
  temperature: 20,
  precipitation: 5,
  vegetationIndex: 0.6,
  showDataOverlay: false,
  
  updateData: () => {
    const farmState = useFarm.getState();
    const { season, day } = farmState;
    
    // Simulate seasonal temperature variations
    const seasonTemp: Record<string, number> = {
      Spring: 15,
      Summer: 28,
      Fall: 18,
      Winter: 5,
    };
    const baseTemp = seasonTemp[season] || 20;
    const dailyVariation = Math.sin(day * 0.1) * 3;
    const temperature = baseTemp + dailyVariation;
    
    // Simulate precipitation patterns
    const seasonRain: Record<string, number> = {
      Spring: 8,
      Summer: 3,
      Fall: 6,
      Winter: 10,
    };
    const basePrecip = seasonRain[season] || 5;
    const precipitation = Math.max(0, basePrecip + Math.random() * 4 - 2);
    
    // Calculate vegetation index based on crop health
    const crops = farmState.crops;
    const avgHealth = crops.length > 0
      ? crops.reduce((sum, c) => sum + c.health, 0) / crops.length
      : 0.3;
    const vegetationIndex = 0.3 + avgHealth * 0.5;
    
    // Update soil moisture based on precipitation and season
    const soilMoisture = Array(25).fill(0).map((_, idx) => {
      const hasCrop = crops.some(c => {
        const gridX = Math.round((c.position[0] + 8) / 4);
        const gridZ = Math.round((c.position[2] + 8) / 4);
        return gridX * 5 + gridZ === idx;
      });
      
      // Base moisture affected by precipitation
      let moisture = 0.3 + (precipitation / 20);
      
      // Crops reduce soil moisture
      if (hasCrop) {
        moisture = Math.max(0.2, moisture - 0.2);
      }
      
      // Add some variation
      moisture += (Math.random() - 0.5) * 0.1;
      
      return Math.max(0, Math.min(1, moisture));
    });
    
    const avgSoilMoisture = soilMoisture.reduce((a, b) => a + b, 0) / soilMoisture.length;
    
    set({
      soilMoisture,
      avgSoilMoisture,
      temperature,
      precipitation,
      vegetationIndex,
    });
  },
  
  toggleDataOverlay: () => set((state) => ({ showDataOverlay: !state.showDataOverlay })),
}));

// Update NASA data periodically
setInterval(() => {
  useNASAData.getState().updateData();
}, 3000); // Update every 3 seconds
