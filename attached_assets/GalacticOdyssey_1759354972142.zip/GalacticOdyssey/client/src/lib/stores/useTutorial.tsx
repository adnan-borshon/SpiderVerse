import { create } from "zustand";

interface TutorialState {
  showTutorial: boolean;
  currentStep: number;
  
  setShowTutorial: (show: boolean) => void;
  setCurrentStep: (step: number) => void;
}

export const useTutorial = create<TutorialState>((set) => ({
  showTutorial: false,
  currentStep: 0,
  
  setShowTutorial: (show) => set({ showTutorial: show }),
  setCurrentStep: (step) => set({ currentStep: step }),
}));
