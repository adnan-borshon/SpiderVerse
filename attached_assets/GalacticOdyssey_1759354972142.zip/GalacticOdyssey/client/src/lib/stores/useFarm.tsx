import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { calculateCropGrowth } from "../game/growthCalculator";

export type Season = "Spring" | "Summer" | "Fall" | "Winter";
export type FarmAction = "plant" | "water" | "fertilize" | "harvest" | "none";
export type CropType = "wheat" | "corn" | "soybean" | "potato";

interface Crop {
  id: string;
  position: [number, number, number];
  type: CropType;
  growth: number;
  health: number;
  plantedDay: number;
  lastWatered: number;
  lastFertilized: number;
}

interface Resources {
  water: number;
  fertilizer: number;
  seeds: number;
}

interface FarmState {
  playerPosition: [number, number, number];
  crops: Crop[];
  fields: boolean[][];
  resources: Resources;
  selectedAction: FarmAction;
  selectedCropType: CropType;
  score: number;
  season: Season;
  day: number;
  timeOfDay: number; // 0-24
  
  // Actions
  setPlayerPosition: (pos: [number, number, number]) => void;
  setSelectedAction: (action: FarmAction) => void;
  setSelectedCropType: (type: CropType) => void;
  performAction: () => void;
  updateCrops: () => void;
  advanceTime: () => void;
  addScore: (points: number) => void;
}

export const useFarm = create<FarmState>()(
  subscribeWithSelector((set, get) => ({
    playerPosition: [0, 0, 0],
    crops: [],
    fields: Array(5).fill(null).map(() => Array(5).fill(false)),
    resources: {
      water: 100,
      fertilizer: 100,
      seeds: 50,
    },
    selectedAction: "none",
    selectedCropType: "wheat",
    score: 0,
    season: "Spring",
    day: 1,
    timeOfDay: 8,

    setPlayerPosition: (pos) => set({ playerPosition: pos }),
    
    setSelectedAction: (action) => set({ selectedAction: action }),
    
    setSelectedCropType: (type) => set({ selectedCropType: type }),
    
    performAction: () => {
      const state = get();
      const { selectedAction, selectedCropType, playerPosition, resources, crops, day } = state;
      
      // Calculate grid position from player position
      const gridX = Math.round((playerPosition[0] + 8) / 4);
      const gridZ = Math.round((playerPosition[2] + 8) / 4);
      
      if (gridX < 0 || gridX >= 5 || gridZ < 0 || gridZ >= 5) return;
      
      const cropId = `${gridX}-${gridZ}`;
      const existingCrop = crops.find(c => c.id === cropId);
      
      switch (selectedAction) {
        case "plant":
          if (!existingCrop && resources.seeds > 0) {
            const newCrop: Crop = {
              id: cropId,
              position: [gridX * 4 - 8, 0, gridZ * 4 - 8],
              type: selectedCropType,
              growth: 0,
              health: 1,
              plantedDay: day,
              lastWatered: day,
              lastFertilized: 0,
            };
            set({
              crops: [...crops, newCrop],
              resources: { ...resources, seeds: resources.seeds - 1 },
            });
            (window as any).playPlantSound?.();
          }
          break;
          
        case "water":
          if (existingCrop && resources.water > 0) {
            const updatedCrops = crops.map(c =>
              c.id === cropId
                ? { ...c, lastWatered: day, health: Math.min(1, c.health + 0.1) }
                : c
            );
            set({
              crops: updatedCrops,
              resources: { ...resources, water: resources.water - 5 },
            });
            (window as any).playWaterSound?.();
          }
          break;
          
        case "fertilize":
          if (existingCrop && resources.fertilizer > 0) {
            const updatedCrops = crops.map(c =>
              c.id === cropId
                ? { ...c, lastFertilized: day, health: Math.min(1, c.health + 0.2) }
                : c
            );
            set({
              crops: updatedCrops,
              resources: { ...resources, fertilizer: resources.fertilizer - 10 },
            });
            (window as any).playPlantSound?.();
          }
          break;
          
        case "harvest":
          if (existingCrop && existingCrop.growth >= 0.95) {
            const points = Math.floor(existingCrop.health * 100);
            set({
              crops: crops.filter(c => c.id !== cropId),
              score: state.score + points,
            });
            (window as any).playHarvestSound?.();
          }
          break;
      }
    },
    
    updateCrops: () => {
      const state = get();
      const updatedCrops = state.crops.map(crop => {
        const daysSincePlanted = state.day - crop.plantedDay;
        const daysSinceWatered = state.day - crop.lastWatered;
        
        // Calculate growth
        const newGrowth = calculateCropGrowth(crop, state);
        
        // Decrease health if not watered
        let newHealth = crop.health;
        if (daysSinceWatered > 2) {
          newHealth = Math.max(0, crop.health - 0.05);
        }
        
        return {
          ...crop,
          growth: Math.min(1, newGrowth),
          health: newHealth,
        };
      });
      
      set({ crops: updatedCrops });
    },
    
    advanceTime: () => {
      const state = get();
      let newTimeOfDay = state.timeOfDay + 1;
      let newDay = state.day;
      let newSeason = state.season;
      
      if (newTimeOfDay >= 24) {
        newTimeOfDay = 0;
        newDay++;
        
        // Update crops daily
        state.updateCrops();
        
        // Replenish resources slowly
        set({
          resources: {
            water: Math.min(100, state.resources.water + 10),
            fertilizer: Math.min(100, state.resources.fertilizer + 5),
            seeds: Math.min(50, state.resources.seeds + 2),
          }
        });
        
        // Change season every 30 days
        if (newDay % 30 === 0) {
          const seasons: Season[] = ["Spring", "Summer", "Fall", "Winter"];
          const currentIndex = seasons.indexOf(state.season);
          newSeason = seasons[(currentIndex + 1) % 4];
        }
      }
      
      set({
        timeOfDay: newTimeOfDay,
        day: newDay,
        season: newSeason,
      });
    },
    
    addScore: (points) => set((state) => ({ score: state.score + points })),
  }))
);

// Auto-advance time
setInterval(() => {
  useFarm.getState().advanceTime();
}, 5000); // Advance time every 5 seconds
