import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import { useGame } from "./lib/stores/useGame";
import "@fontsource/inter";

// Import game components
import Scene from "./components/game/Scene";
import Lights from "./components/game/Lights";
import GameUI from "./components/ui/GameUI";
import Menu from "./components/ui/Menu";
import SoundManager from "./components/game/SoundManager";

// Define control keys for farming game
export enum Controls {
  forward = 'forward',
  backward = 'backward',
  leftward = 'leftward',
  rightward = 'rightward',
  interact = 'interact',
  plant = 'plant',
  water = 'water',
  fertilize = 'fertilize',
  harvest = 'harvest',
}

// Main App component
function App() {
  const { phase } = useGame();

  // Define key mappings
  const keyMap = [
    { name: Controls.forward, keys: ['KeyW', 'ArrowUp'] },
    { name: Controls.backward, keys: ['KeyS', 'ArrowDown'] },
    { name: Controls.leftward, keys: ['KeyA', 'ArrowLeft'] },
    { name: Controls.rightward, keys: ['KeyD', 'ArrowRight'] },
    { name: Controls.interact, keys: ['KeyE'] },
    { name: Controls.plant, keys: ['Digit1'] },
    { name: Controls.water, keys: ['Digit2'] },
    { name: Controls.fertilize, keys: ['Digit3'] },
    { name: Controls.harvest, keys: ['Space'] },
  ];

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <KeyboardControls map={keyMap}>
        {phase === 'ready' && <Menu />}

        {(phase === 'playing' || phase === 'ended') && (
          <>
            <Canvas
              shadows
              camera={{
                position: [0, 15, 20],
                fov: 60,
                near: 0.1,
                far: 1000
              }}
              gl={{
                antialias: true,
                powerPreference: "high-performance"
              }}
            >
              <color attach="background" args={["#87CEEB"]} />

              {/* Lighting */}
              <Lights />

              <Suspense fallback={null}>
                <Scene />
              </Suspense>
            </Canvas>
            <GameUI />
          </>
        )}

        <SoundManager />
      </KeyboardControls>
    </div>
  );
}

export default App;
